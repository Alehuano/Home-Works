def divide(first, second):
    if second != 0:
        div = first / second
    else:
        div = "Ошибка"
    return div
